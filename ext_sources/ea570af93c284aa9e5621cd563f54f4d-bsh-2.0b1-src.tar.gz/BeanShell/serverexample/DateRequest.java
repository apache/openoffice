//file: DateRequest.java
public class DateRequest extends Request {}
