
class MyObjectOutputStream extends ObjectOutputStream 
{
	MyObjectOutputStream( OutputStream out ) {
		super(out);
		enableReplaceObject(true);
		print("here");
	}
	public Object replaceObject( Object o ) {
		print("writing: "+o);
		return o;
	}
}

f=new FileOutputStream("out.ser");
moo = new MyObjectOutputStream( f );
h=new HashMap();
h.put("foo","bar");
h.put("goo", new Date());
moo.writeObject( h );
