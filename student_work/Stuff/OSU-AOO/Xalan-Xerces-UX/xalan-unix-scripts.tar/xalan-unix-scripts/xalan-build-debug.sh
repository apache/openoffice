#!/bin/sh

#export SourceDir=/data/apache/xalan/c/trunk
export SourceDir=$HOME/xalan-src/c
export DestDir=/opt/apache/debug

export XERCESCROOT=${DestDir}
export XALANCROOT=${SourceDir}

export LD_LIBRARY_PATH=${DestDir}/lib:${LD_LIBRARY_PATH}
export PATH=$PATH:${SourceDir}

runConfigure -p linux -c gcc -x g++ -d -P "${DestDir}" -C "--srcdir=${SourceDir}"

# Connect to subdirectories to build only the libraries and Xalan command line program
# Comment out the subdirectory cd's to also build the sample programs.
cd src
cd xalanc

make clean

make

make install

