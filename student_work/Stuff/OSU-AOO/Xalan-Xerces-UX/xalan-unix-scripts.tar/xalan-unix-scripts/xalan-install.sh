#!/bin/sh
#
# This script assumes that "xalan-build.sh" has already been run.
# This script should be run from your build directory.  If you are
# installing to a system directory /usr or /usr/local you may need
# to run this script as root or superuser.
#
cd src
cd xalanc

make install


