#!/bin/sh

#export SourceDir=/data/apache/xerces-src
export SourceDir=$HOME/xerces-src
export DestDir=/opt/apache

PATH=$PATH:$SourceDir

configure CC="gcc" CXX="g++" CFLAGS=-O3 CXXFLAGS=-O3 --srcdir=${SourceDir} --prefix=${DestDir}

cd src
make clean
make
make install
