#**************************************************************
#  
#  Licensed to the Apache Software Foundation (ASF) under one
#  or more contributor license agreements.  See the NOTICE file
#  distributed with this work for additional information
#  regarding copyright ownership.  The ASF licenses this file
#  to you under the Apache License, Version 2.0 (the
#  "License"); you may not use this file except in compliance
#  with the License.  You may obtain a copy of the License at
#  
#    http://www.apache.org/licenses/LICENSE-2.0
#  
#  Unless required by applicable law or agreed to in writing,
#  software distributed under the License is distributed on an
#  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
#  KIND, either express or implied.  See the License for the
#  specific language governing permissions and limitations
#  under the License.
#  
#**************************************************************

PRJ=..$/..$/..$/..$/..$/..$/..

PRJNAME=icc
TARGET=create_sRGB_profile
LIBTARGET=NO
TARGETTYPE=CUI

ENABLE_EXCEPTIONS=TRUE

EXTERNAL_WARNINGS_NOT_ERRORS=TRUE

# --- Settings -----------------------------------------------------

.INCLUDE :	settings.mk

CFLAGS+=-I..$/..$/..$/IccProfLib -I..$/..$/ICC_utils

# This tool uses unaligned memory accesses which will lead
# to SIGBUS on platforms who care, like Solaris LP64
.IF "$(OS)$(CPU)"=="SOLARISU"
LINKFLAGS+=-xmemalign=8i
.ENDIF

# --- Files --------------------------------------------------------

OBJFILES= $(OBJ)$/create_sRGB_profile.obj

# --- Targets ------------------------------------------------------

# svdem
APP1LIBSALCPPRT:=
UWINAPILIB:=
APP1NOSAL=		TRUE
APP1TARGET= 	$(TARGET)
APP1LIBS=\
    $(SLB)$/proflib.lib \
    $(SLB)$/icutil.lib
APP1OBJS= $(OBJFILES)
APP1STDLIBS=

.INCLUDE :	target.mk

ALLTAR: $(TARGET)$(EXECPOST)

$(TARGET)$(EXECPOST): $(BIN)$/$(TARGET)$(EXECPOST) makefile.mk
    rm -f $@
    $(GNUCOPY) $(BIN)$/$(TARGET)$(EXECPOST) $@
